/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

void Luas_Persegi () {
        int s;
        float sum;
        cout << "Luas Persegi" << endl;
        cout << "Rumus = sisi * sisi" << endl;
        cout << "Masukkan panjang sisi : ";
        cin >> s;
        sum = s * s;
        cout << "hasil : " << sum << endl;
}

void Luas_Lingkaran () {
    int r;
    float phi = 3.14, sum;
    cout << "Luas Lingkaran" << endl;
    cout << "Rumus = phi * r^2" << endl;
    cout << "Masukkan panjang jari-jari : ";
    cin >> r;
    sum = phi * (r*r);
    cout << "Hasil : " << sum << endl;
}

void Luas_Persegi_Panjang () {
    int p,l;
    float sum;
    cout << "Luas Persegi Panjang" << endl;
    cout << "Rumus = p * l" << endl;
    cout << "Masukkan Panjang persegi panjang : ";
    cin >> p;
    cout << "Masukkan Lebar persegi panjang :";
    cin >> l;
    sum = p * l;
    cout << "Hasil : " << sum << endl;
}
        
int main()
{
    Luas_Persegi();
    Luas_Lingkaran ();
    Luas_Persegi_Panjang();
}
    
    
