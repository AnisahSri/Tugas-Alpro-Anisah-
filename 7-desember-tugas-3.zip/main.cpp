/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main (){
  int pilihan, jumlah_penumpang, harga, total, diskon;
  string kelas;
  cout << "1. Ekonomi (100.000,-/tiket)" << endl;
  cout << "2. Bisnis (200.000,-/tiket)" << endl;
  cout << "3. Eksekutif (300.000,-/tiket)" << endl;

  cout << "Masukkan Pilihan : ";
  cin >> pilihan;

  switch (pilihan) {
    case 1:
      kelas = "Ekonomi";
      harga = 100000;
      cout << "Jumlah penumpang : ";
      cin >> jumlah_penumpang;
      total += harga * jumlah_penumpang;
      cout << jumlah_penumpang << " " << kelas << " = Rp. " << harga *	jumlah_penumpang << endl << endl;
      break;
    case 2:
      kelas = "Bisnis";
      harga = 200000;
      cout << "Jumlah penumpang : ";
      cin >> jumlah_penumpang;
      total += harga * jumlah_penumpang;
      cout << jumlah_penumpang << " " << kelas << " = Rp.  " << harga *	jumlah_penumpang << endl << endl;
      break;
    case 3:
      kelas = "Eksekutif";
      harga = 300000;
      cout << "Jumlah penumpang : ";
      cin >> jumlah_penumpang;
      total += harga * jumlah_penumpang;
      cout << jumlah_penumpang << " " << kelas << " = Rp." << harga *	jumlah_penumpang << endl << endl;
      break;
      default:
      cout << "Pilihan Anda Tidak Tersedia!" << endl;
      break;
  }
      cout << "Jumlah Bayar : " << total << endl;

      if (total >= 500000)	{
	  diskon = 0.1 * total;
	}
      else if (total >= 300000) {
	  diskon = 0.05 * total;
	}
      else if (total >= 200000)	{
	  diskon = 0.02 * total;
	}
      else	{
	  diskon = 0;
	}
      cout << "Diskon      : " << diskon << endl;
      cout << "Total Bayar : " << total - diskon << endl;
      cout << "Terima Kasih " << endl; 
  return 0;
}


