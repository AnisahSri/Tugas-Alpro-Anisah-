/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void startGame () {
   int Hp = 200;
   int Exp = 100;
   int Zeny = 100;
   int aksi;
   int Senjata;
   string namaSenjata;
   cout << "\nHp = 200 , Exp = 100 , Zeny = 100";
   cout << "\nSenjata = ";
     do {
         string Opsi;
         cout << "\n1. SERANG (-10 Hp +10 Exp)";
         cout << "\n2. MEMULIHKAN (+10 Hp +5 Exp -5 Zeny)";
         cout << "\n3. BELI SENJATA";
         cout << "\n4. KELUAR";
         cout << "\nApa Opsi Yang Kamu Pilih : " << endl;
         cin >> aksi;
     switch (aksi) {
         case 1:
         Hp -= 10;
         Exp += 10;
         Zeny +=0;
         cout << "Hp: " << Hp << "\nExp : " << Exp << "\nZeny : " << Zeny << "\nSenjata = " << namaSenjata;
         cout << "\nKAMU MELAKUKAN SERANG" << endl;
         break;
         case 2:
         Hp += 10;
         Exp += 5;
         Zeny -= 5;
         cout << "Hp: " << Hp << "\nExp : " << Exp << "\nZeny : " << Zeny << "\nSenjata = " << namaSenjata;
         cout << "\nKAMU MEMULIHKAN" << namaSenjata << endl;
         break;
         case 3:
         int Senjata;
         cout << "1. PANAH (15)" << endl;
         cout << "2. PEDANG (25) " << endl;
         cout << "Pilihan Senjata : " << endl;
         cin >> Senjata;
         if (Senjata == 1) {
             namaSenjata = " PANAH ";
             Zeny -=15;
             cout << "Zeny : " << Zeny;
             cout << "\nSenjata Yang Kamu Pilih Adalah" << namaSenjata << endl; 
        } else if (Senjata == 2) {
            namaSenjata = " PEDANG ";
             Zeny -=25;
             cout << "Zeny : " << Zeny;
             cout << "\nSenjata Yang Kamu Pilih Adalah" << namaSenjata << endl;
        } else {
            cout << "Zeny Tidak Tersisa" << endl;
         break;
         case 4:
         cout << "Bye-Bye" << endl;
        break;
        
        default:
        cout << "Pilihan Anda Tidak Tersedia!";
        break;
        }
        
     }
       } while (aksi !=4);
}
int main()
{
    int Pilihan, aksi;
    string memilih;
    cout << "1. BERMAIN" << endl;
    cout << "2. KELUAR" << endl;
    cout << "Masukkan Pilihan :" << endl;
    cin >> Pilihan;
    
    switch (Pilihan) {
        case 1:
        int Jenis_karakter;
        cout << "Pilihan Karakter :" << endl; 
        cout << "1. KSATRIA" << endl;
        cout << "2. PEMANAH" << endl; 
        cout << "3. MEDIS" << endl;
        cin >> Jenis_karakter;
        if (Jenis_karakter == 1 ) {
            cout << "PEMAIN KAMU ADALAH KSATRIA" << endl;
            startGame ();
        }else if (Jenis_karakter == 2 ) {
            cout << "PEMAIN KAMU ADALAH PEMANAH" << endl;
            startGame ();
        }else if (Jenis_karakter == 3 ) {
            cout << "KAMU MEMILIH PETUGAS MEDIS" << endl;
            startGame ();
        }else {
            cout << "Tidak Ada Pemain atau Petugas" << endl;
        }
        break;
        case 2:
        cout << "Bye-Bye" << endl;
        break;
    }
    return 0;
     }
















